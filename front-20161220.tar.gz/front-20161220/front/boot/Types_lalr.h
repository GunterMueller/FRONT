#ifndef _Types_lalr_h
#define _Types_lalr_h

#include "Types.h"

#include <front/parse_support.h>

List_Types_EnumType Parse_state_Types_OPTMORE_EnumType (void);	/* state 0 */
List_Types_PointerType Parse_state_Types_OPTMORE_PointerType (void);	/* state 21 */
List_Types_subtypedef Parse_state_Types_OPTMORE_subtypedef (void);	/* state 41 */
Types_includes2 Parse_state_Types_includes2 (void);	/* state 42 */
List_Types_BindType Parse_state_Types_OPTMORE_BindType (void);	/* state 58 */
List_Types_StructType Parse_state_Types_OPTMORE_StructType (void);	/* state 83 */
Types_Types Parse_state_Types_Types (void);	/* state 151 */
List_Ident Parse_state_Types_OPTMORE_hashincludespacebackslashdoublequotesym_Identsym_dothbackslashdoublequotesym (void);	/* state 168 */
List_Types_TypeName Parse_state_Types_Enums (void);	/* state 169 */
Types_EnumType Parse_state_Types_EnumType (void);	/* state 170 */
List_Types_TypeName Parse_state_Types_ALT_TypeName_SEP_commasym_NL (void);	/* state 171 */
Types_BindType Parse_state_Types_BindType (void);	/* state 172 */
Types_PointerType Parse_state_Types_PointerType (void);	/* state 173 */
Types_subtypedef Parse_state_Types_subtypedef (void);	/* state 174 */
Types_struct_type Parse_state_Types_struct_type (void);	/* state 175 */
List_Types_macro Parse_state_Types_OPTMORE_macro (void);	/* state 176 */
List_Types_CreateFunction Parse_state_Types_OPTMORE_CreateFunction (void);	/* state 177 */
Types_StructType Parse_state_Types_StructType (void);	/* state 178 */
List_Types_field Parse_state_Types_OPTMORE_field (void);	/* state 179 */
List_Types_struct_type Parse_state_Types_OPTMORE_struct_type (void);	/* state 180 */
List_Types_struct_type Parse_state_Types_sub_union (void);	/* state 181 */
List_Ident Parse_state_Types_OPTMORE_dotsubdotsym_Identsym (void);	/* state 182 */
Types_macro Parse_state_Types_macro (void);	/* state 183 */
List_Types_TypeName Parse_state_Types_TypeNames (void);	/* state 184 */
Types_field Parse_state_Types_field (void);	/* state 185 */
Types_TypeName Parse_state_Types_TypeName (void);	/* state 186 */
Types_CreateFunction Parse_state_Types_CreateFunction (void);	/* state 187 */
List_Types_TypeName Parse_state_Types_ALT_TypeName_SEP__sym (void);	/* state 188 */

#endif /* _Types_lalr_h */
