#ifndef _Diagrams_lalr_h
#define _Diagrams_lalr_h

#include "Diagrams.h"

#include "parse_support.h"

List_Diagrams_Picture Parse_state_Diagrams_OPTMORE_Picture (void);	/* state 0 */
Diagrams_Diagrams Parse_state_Diagrams_Diagrams (void);	/* state 44 */
Diagrams_Direction Parse_state_Diagrams_Direction (void);	/* state 46 */
Diagrams_Picture Parse_state_Diagrams_Picture (void);	/* state 47 */
List_Diagrams_Picture Parse_state_Diagrams_MORE_Picture (void);	/* state 48 */

#endif /* _Diagrams_lalr_h */
