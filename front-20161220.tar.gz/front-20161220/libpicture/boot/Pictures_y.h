/* A Bison parser, made by GNU Bison 2.1.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     NONSENSE = 258,
     rectanglesym = 259,
     circlesym = 260,
     arcsym = 261,
     arctopopsym = 262,
     linesym = 263,
     trianglesym = 264,
     eofillsym = 265,
     Lsym = 266,
     Rsym = 267,
     Usym = 268,
     Dsym = 269,
     Csym = 270,
     openparsym = 271,
     closeparsym = 272,
     ORspacesym = 273,
     ENDORsym = 274,
     ANDspacesym = 275,
     ENDANDsym = 276,
     ALTspacesym = 277,
     ENDALTsym = 278,
     Boolsym = 279,
     Floatsym = 280,
     Stringsym = 281,
     Identsym = 282,
     hole_Pictures = 283,
     start_Pictures = 284,
     hole_Direction = 285,
     start_Direction = 286,
     hole_Picture = 287,
     start_Picture = 288,
     hole_OPTMORE_Picture = 289,
     start_OPTMORE_Picture = 290,
     hole_MORE_Picture = 291,
     start_MORE_Picture = 292
   };
#endif
/* Tokens.  */
#define NONSENSE 258
#define rectanglesym 259
#define circlesym 260
#define arcsym 261
#define arctopopsym 262
#define linesym 263
#define trianglesym 264
#define eofillsym 265
#define Lsym 266
#define Rsym 267
#define Usym 268
#define Dsym 269
#define Csym 270
#define openparsym 271
#define closeparsym 272
#define ORspacesym 273
#define ENDORsym 274
#define ANDspacesym 275
#define ENDANDsym 276
#define ALTspacesym 277
#define ENDALTsym 278
#define Boolsym 279
#define Floatsym 280
#define Stringsym 281
#define Identsym 282
#define hole_Pictures 283
#define start_Pictures 284
#define hole_Direction 285
#define start_Direction 286
#define hole_Picture 287
#define start_Picture 288
#define hole_OPTMORE_Picture 289
#define start_OPTMORE_Picture 290
#define hole_MORE_Picture 291
#define start_MORE_Picture 292




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)

typedef union YYSTYPE {
Bool Boolsym_type;
Float Floatsym_type;
String Stringsym_type;
Ident Identsym_type;
Pictures_Pictures Pictures_type;
Pictures_Direction Direction_type;
Pictures_Picture Picture_type;
List_Pictures_Picture OPTMORE_Picture_type;
struct {
  List_Pictures_Picture f1;
  List_Pictures_Direction f2;
} ALT_ORspacesym_Picture_SEP_Direction_ENDORsym_NL_type;
struct {
  List_Pictures_Picture f1;
  List_Pictures_Direction f2;
} ALT_ANDspacesym_Picture_SEP_Direction_ENDANDsym_NL_type;
List_Pictures_Picture MORE_Picture_type;
} YYSTYPE;
/* Line 1447 of yacc.c.  */

# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE Pictures_lval;

#if ! defined (YYLTYPE) && ! defined (YYLTYPE_IS_DECLARED)
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif

extern YYLTYPE Pictures_lloc;


