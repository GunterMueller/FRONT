#ifndef _Pictures_lalr_h
#define _Pictures_lalr_h

#include "Pictures.h"

#include <front/parse_support.h>

List_Pictures_Picture Parse_state_Pictures_OPTMORE_Picture (void);	/* state 0 */
Pictures_Pictures Parse_state_Pictures_Pictures (void);	/* state 48 */
Pictures_Direction Parse_state_Pictures_Direction (void);	/* state 50 */
Pictures_Picture Parse_state_Pictures_Picture (void);	/* state 51 */
List_Pictures_Picture Parse_state_Pictures_MORE_Picture (void);	/* state 52 */

#endif /* _Pictures_lalr_h */
