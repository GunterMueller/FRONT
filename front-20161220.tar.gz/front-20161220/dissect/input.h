#ifndef _dissect_input_h
#define _dissect_input_h

FILE *open_log (char *filename);
FILE *pipe_log (char **argv);

#endif /* _dissect_input_h */
