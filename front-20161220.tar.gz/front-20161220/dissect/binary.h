#ifndef _dissect_binary_h
#define _dissect_binary_h

int scan_binary(char *program);

#endif /* _dissect_binary_h */
