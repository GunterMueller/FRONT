/* A Bison parser, made by GNU Bison 2.1.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     NONSENSE = 258,
     usessym = 259,
     commasym = 260,
     semicolonsym = 261,
     fatalsym = 262,
     errorsym = 263,
     warningsym = 264,
     disabledsym = 265,
     keysym = 266,
     postsym = 267,
     openparsym = 268,
     closeparsym = 269,
     groupsym = 270,
     openchainsym = 271,
     equalssym = 272,
     closechainsym = 273,
     commentsym = 274,
     Stringsym = 275,
     Identsym = 276,
     hole_egg = 277,
     start_egg = 278,
     hole_Uses = 279,
     start_Uses = 280,
     hole_Strings = 281,
     start_Strings = 282,
     hole_Declarations = 283,
     start_Declarations = 284,
     hole_Declaration = 285,
     start_Declaration = 286,
     hole_Expression = 287,
     start_Expression = 288,
     hole_Params = 289,
     start_Params = 290,
     hole_Statements = 291,
     start_Statements = 292,
     hole_Statement = 293,
     start_Statement = 294,
     hole_MessageKind = 295,
     start_MessageKind = 296,
     hole_Message = 297,
     start_Message = 298,
     hole_SubMessages = 299,
     start_SubMessages = 300,
     hole_SubMessage = 301,
     start_SubMessage = 302,
     hole_Group = 303,
     start_Group = 304,
     hole_OPTMORE_Group = 305,
     start_OPTMORE_Group = 306,
     hole_ALT_Stringsym_SEP_commasym = 307,
     start_ALT_Stringsym_SEP_commasym = 308,
     hole_OPTMORE_Declaration = 309,
     start_OPTMORE_Declaration = 310,
     hole_MORE_Expression = 311,
     start_MORE_Expression = 312,
     hole_ALT_Expression_SEP_commasym = 313,
     start_ALT_Expression_SEP_commasym = 314,
     hole_OPTMORE_Statement = 315,
     start_OPTMORE_Statement = 316,
     hole_OPT_fatalsym = 317,
     start_OPT_fatalsym = 318,
     hole_ALT_SubMessage_SEP_commasym = 319,
     start_ALT_SubMessage_SEP_commasym = 320,
     hole_OPT_openparsym_Identsym_closeparsym = 321,
     start_OPT_openparsym_Identsym_closeparsym = 322,
     hole_OPT_groupsym = 323,
     start_OPT_groupsym = 324
   };
#endif
/* Tokens.  */
#define NONSENSE 258
#define usessym 259
#define commasym 260
#define semicolonsym 261
#define fatalsym 262
#define errorsym 263
#define warningsym 264
#define disabledsym 265
#define keysym 266
#define postsym 267
#define openparsym 268
#define closeparsym 269
#define groupsym 270
#define openchainsym 271
#define equalssym 272
#define closechainsym 273
#define commentsym 274
#define Stringsym 275
#define Identsym 276
#define hole_egg 277
#define start_egg 278
#define hole_Uses 279
#define start_Uses 280
#define hole_Strings 281
#define start_Strings 282
#define hole_Declarations 283
#define start_Declarations 284
#define hole_Declaration 285
#define start_Declaration 286
#define hole_Expression 287
#define start_Expression 288
#define hole_Params 289
#define start_Params 290
#define hole_Statements 291
#define start_Statements 292
#define hole_Statement 293
#define start_Statement 294
#define hole_MessageKind 295
#define start_MessageKind 296
#define hole_Message 297
#define start_Message 298
#define hole_SubMessages 299
#define start_SubMessages 300
#define hole_SubMessage 301
#define start_SubMessage 302
#define hole_Group 303
#define start_Group 304
#define hole_OPTMORE_Group 305
#define start_OPTMORE_Group 306
#define hole_ALT_Stringsym_SEP_commasym 307
#define start_ALT_Stringsym_SEP_commasym 308
#define hole_OPTMORE_Declaration 309
#define start_OPTMORE_Declaration 310
#define hole_MORE_Expression 311
#define start_MORE_Expression 312
#define hole_ALT_Expression_SEP_commasym 313
#define start_ALT_Expression_SEP_commasym 314
#define hole_OPTMORE_Statement 315
#define start_OPTMORE_Statement 316
#define hole_OPT_fatalsym 317
#define start_OPT_fatalsym 318
#define hole_ALT_SubMessage_SEP_commasym 319
#define start_ALT_SubMessage_SEP_commasym 320
#define hole_OPT_openparsym_Identsym_closeparsym 321
#define start_OPT_openparsym_Identsym_closeparsym 322
#define hole_OPT_groupsym 323
#define start_OPT_groupsym 324




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)

typedef union YYSTYPE {
String Stringsym_type;
Ident Identsym_type;
egg_egg egg_type;
egg_Uses Uses_type;
List_String Strings_type;
List_egg_Declaration Declarations_type;
egg_Declaration Declaration_type;
egg_Expression Expression_type;
List_egg_Expression Params_type;
List_egg_Statement Statements_type;
egg_Statement Statement_type;
egg_MessageKind MessageKind_type;
egg_Message Message_type;
List_egg_SubMessage SubMessages_type;
egg_SubMessage SubMessage_type;
egg_Group Group_type;
List_egg_Statement OPTMORE_Group_type;
List_String ALT_Stringsym_SEP_commasym_type;
List_egg_Declaration OPTMORE_Declaration_type;
List_egg_Expression MORE_Expression_type;
List_egg_Expression ALT_Expression_SEP_commasym_type;
List_egg_Statement OPTMORE_Statement_type;
Bool OPT_fatalsym_type;
List_egg_SubMessage ALT_SubMessage_SEP_commasym_type;
Ident OPT_openparsym_Identsym_closeparsym_type;
Bool OPT_groupsym_type;
} YYSTYPE;
/* Line 1447 of yacc.c.  */

# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE egg_lval;

#if ! defined (YYLTYPE) && ! defined (YYLTYPE_IS_DECLARED)
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif

extern YYLTYPE egg_lloc;


