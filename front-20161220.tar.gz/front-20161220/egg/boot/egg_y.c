/* A Bison parser, made by GNU Bison 1.875c.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 1

/* If NAME_PREFIX is specified substitute the variables and functions
   names.  */
#define yyparse egg_parse
#define yylex   egg_lex
#define yyerror egg_error
#define yylval  egg_lval
#define yychar  egg_char
#define yydebug egg_debug
#define yynerrs egg_nerrs
#define yylloc egg_lloc

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     NONSENSE = 258,
     usessym = 259,
     commasym = 260,
     semicolonsym = 261,
     fatalsym = 262,
     errorsym = 263,
     warningsym = 264,
     disabledsym = 265,
     keysym = 266,
     postsym = 267,
     openparsym = 268,
     closeparsym = 269,
     groupsym = 270,
     openchainsym = 271,
     equalssym = 272,
     closechainsym = 273,
     commentsym = 274,
     Stringsym = 275,
     Identsym = 276,
     hole_egg = 277,
     start_egg = 278,
     hole_Uses = 279,
     start_Uses = 280,
     hole_Strings = 281,
     start_Strings = 282,
     hole_Declarations = 283,
     start_Declarations = 284,
     hole_Declaration = 285,
     start_Declaration = 286,
     hole_Expression = 287,
     start_Expression = 288,
     hole_Params = 289,
     start_Params = 290,
     hole_Statements = 291,
     start_Statements = 292,
     hole_Statement = 293,
     start_Statement = 294,
     hole_MessageKind = 295,
     start_MessageKind = 296,
     hole_Message = 297,
     start_Message = 298,
     hole_SubMessages = 299,
     start_SubMessages = 300,
     hole_SubMessage = 301,
     start_SubMessage = 302,
     hole_Group = 303,
     start_Group = 304,
     hole_OPTMORE_Group = 305,
     start_OPTMORE_Group = 306,
     hole_ALT_Stringsym_SEP_commasym = 307,
     start_ALT_Stringsym_SEP_commasym = 308,
     hole_OPTMORE_Declaration = 309,
     start_OPTMORE_Declaration = 310,
     hole_MORE_Expression = 311,
     start_MORE_Expression = 312,
     hole_ALT_Expression_SEP_commasym = 313,
     start_ALT_Expression_SEP_commasym = 314,
     hole_OPTMORE_Statement = 315,
     start_OPTMORE_Statement = 316,
     hole_OPT_fatalsym = 317,
     start_OPT_fatalsym = 318,
     hole_ALT_SubMessage_SEP_commasym = 319,
     start_ALT_SubMessage_SEP_commasym = 320,
     hole_OPT_openparsym_Identsym_closeparsym = 321,
     start_OPT_openparsym_Identsym_closeparsym = 322,
     hole_OPT_groupsym = 323,
     start_OPT_groupsym = 324
   };
#endif
#define NONSENSE 258
#define usessym 259
#define commasym 260
#define semicolonsym 261
#define fatalsym 262
#define errorsym 263
#define warningsym 264
#define disabledsym 265
#define keysym 266
#define postsym 267
#define openparsym 268
#define closeparsym 269
#define groupsym 270
#define openchainsym 271
#define equalssym 272
#define closechainsym 273
#define commentsym 274
#define Stringsym 275
#define Identsym 276
#define hole_egg 277
#define start_egg 278
#define hole_Uses 279
#define start_Uses 280
#define hole_Strings 281
#define start_Strings 282
#define hole_Declarations 283
#define start_Declarations 284
#define hole_Declaration 285
#define start_Declaration 286
#define hole_Expression 287
#define start_Expression 288
#define hole_Params 289
#define start_Params 290
#define hole_Statements 291
#define start_Statements 292
#define hole_Statement 293
#define start_Statement 294
#define hole_MessageKind 295
#define start_MessageKind 296
#define hole_Message 297
#define start_Message 298
#define hole_SubMessages 299
#define start_SubMessages 300
#define hole_SubMessage 301
#define start_SubMessage 302
#define hole_Group 303
#define start_Group 304
#define hole_OPTMORE_Group 305
#define start_OPTMORE_Group 306
#define hole_ALT_Stringsym_SEP_commasym 307
#define start_ALT_Stringsym_SEP_commasym 308
#define hole_OPTMORE_Declaration 309
#define start_OPTMORE_Declaration 310
#define hole_MORE_Expression 311
#define start_MORE_Expression 312
#define hole_ALT_Expression_SEP_commasym 313
#define start_ALT_Expression_SEP_commasym 314
#define hole_OPTMORE_Statement 315
#define start_OPTMORE_Statement 316
#define hole_OPT_fatalsym 317
#define start_OPT_fatalsym 318
#define hole_ALT_SubMessage_SEP_commasym 319
#define start_ALT_SubMessage_SEP_commasym 320
#define hole_OPT_openparsym_Identsym_closeparsym 321
#define start_OPT_openparsym_Identsym_closeparsym 322
#define hole_OPT_groupsym 323
#define start_OPT_groupsym 324




/* Copy the first part of user declarations.  */


#include <string.h>
#include "front/scan_support.h"
#include "front/parse_support.h"
#include "egg.h"

extern int input_line_nr;

struct yy_buffer_state *egg_dummy_state (void);
struct yy_buffer_state *egg_scanner_state (void);


/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)

typedef union YYSTYPE {
String Stringsym_type;
Ident Identsym_type;
egg_egg egg_type;
egg_Uses Uses_type;
List_String Strings_type;
List_egg_Declaration Declarations_type;
egg_Declaration Declaration_type;
egg_Expression Expression_type;
List_egg_Expression Params_type;
List_egg_Statement Statements_type;
egg_Statement Statement_type;
egg_MessageKind MessageKind_type;
egg_Message Message_type;
List_egg_SubMessage SubMessages_type;
egg_SubMessage SubMessage_type;
egg_Group Group_type;
List_egg_Statement OPTMORE_Group_type;
List_String ALT_Stringsym_SEP_commasym_type;
List_egg_Declaration OPTMORE_Declaration_type;
List_egg_Expression MORE_Expression_type;
List_egg_Expression ALT_Expression_SEP_commasym_type;
List_egg_Statement OPTMORE_Statement_type;
Bool OPT_fatalsym_type;
List_egg_SubMessage ALT_SubMessage_SEP_commasym_type;
Ident OPT_openparsym_Identsym_closeparsym_type;
Bool OPT_groupsym_type;
} YYSTYPE;
/* Line 191 of yacc.c.  */

# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

#if ! defined (YYLTYPE) && ! defined (YYLTYPE_IS_DECLARED)
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif


/* Copy the second part of user declarations.  */


/* Line 214 of yacc.c.  */


#if ! defined (yyoverflow) || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   define YYSTACK_ALLOC alloca
#  endif
# else
#  if defined (alloca) || defined (_ALLOCA_H)
#   define YYSTACK_ALLOC alloca
#  else
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC malloc
#  define YYSTACK_FREE free
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (defined (YYLTYPE_IS_TRIVIAL) && YYLTYPE_IS_TRIVIAL \
             && defined (YYSTYPE_IS_TRIVIAL) && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short yyss;
  YYSTYPE yyvs;
    YYLTYPE yyls;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE) + sizeof (YYLTYPE))	\
      + 2 * YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined (__GNUC__) && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  106
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   268

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  70
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  25
/* YYNRULES -- Number of rules. */
#define YYNRULES  90
/* YYNRULES -- Number of states. */
#define YYNSTATES  139

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   324

#define YYTRANSLATE(YYX) 						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned char yyprhs[] =
{
       0,     0,     3,     6,    10,    12,    14,    19,    21,    26,
      28,    30,    32,    34,    36,    38,    40,    42,    44,    46,
      51,    53,    56,    65,    66,    69,    71,    75,    76,    79,
      81,    84,    86,    90,    91,    94,    95,    97,    99,   103,
     104,   108,   109,   111,   113,   116,   118,   121,   123,   126,
     128,   131,   133,   136,   138,   141,   143,   146,   148,   151,
     153,   156,   158,   161,   163,   166,   168,   171,   173,   176,
     178,   181,   183,   186,   188,   191,   193,   196,   198,   201,
     203,   206,   208,   211,   213,   216,   218,   221,   223,   226,
     228
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const yysigned_char yyrhs[] =
{
      71,     0,    -1,    72,    85,    -1,     4,    73,     6,    -1,
      86,    -1,    87,    -1,    80,    17,    88,     6,    -1,    20,
      -1,    21,    13,    77,    14,    -1,    21,    -1,    89,    -1,
      90,    -1,    81,    -1,    84,    -1,     8,    -1,     9,    -1,
      10,    -1,    11,    -1,    12,    -1,    91,    21,    82,     6,
      -1,    92,    -1,    80,    20,    -1,    91,    21,    93,    94,
      16,    74,    78,    18,    -1,    -1,    84,    85,    -1,    20,
      -1,    20,     5,    86,    -1,    -1,    75,    87,    -1,    76,
      -1,    76,    88,    -1,    76,    -1,    76,     5,    89,    -1,
      -1,    79,    90,    -1,    -1,     7,    -1,    83,    -1,    83,
       5,    92,    -1,    -1,    13,    21,    14,    -1,    -1,    15,
      -1,    22,    -1,    23,    71,    -1,    24,    -1,    25,    72,
      -1,    26,    -1,    27,    73,    -1,    28,    -1,    29,    74,
      -1,    30,    -1,    31,    75,    -1,    32,    -1,    33,    76,
      -1,    34,    -1,    35,    77,    -1,    36,    -1,    37,    78,
      -1,    38,    -1,    39,    79,    -1,    40,    -1,    41,    80,
      -1,    42,    -1,    43,    81,    -1,    44,    -1,    45,    82,
      -1,    46,    -1,    47,    83,    -1,    48,    -1,    49,    84,
      -1,    50,    -1,    51,    85,    -1,    52,    -1,    53,    86,
      -1,    54,    -1,    55,    87,    -1,    56,    -1,    57,    88,
      -1,    58,    -1,    59,    89,    -1,    60,    -1,    61,    90,
      -1,    62,    -1,    63,    91,    -1,    64,    -1,    65,    92,
      -1,    66,    -1,    67,    93,    -1,    68,    -1,    69,    94,
      -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short yyrline[] =
{
       0,   158,   158,   166,   174,   182,   190,   199,   205,   214,
     220,   228,   236,   243,   250,   256,   262,   268,   274,   280,
     289,   297,   304,   319,   325,   333,   340,   349,   355,   363,
     370,   378,   385,   394,   400,   408,   414,   421,   428,   437,
     443,   452,   458,   465,   470,   476,   481,   487,   492,   498,
     503,   509,   514,   520,   525,   531,   536,   542,   547,   553,
     558,   564,   569,   575,   580,   586,   591,   597,   602,   608,
     613,   619,   624,   630,   635,   641,   646,   652,   657,   663,
     668,   674,   679,   685,   690,   696,   701,   707,   712,   718,
     723
};
#endif

#if YYDEBUG || YYERROR_VERBOSE
/* YYTNME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "NONSENSE", "usessym", "commasym",
  "semicolonsym", "fatalsym", "errorsym", "warningsym", "disabledsym",
  "keysym", "postsym", "openparsym", "closeparsym", "groupsym",
  "openchainsym", "equalssym", "closechainsym", "commentsym", "Stringsym",
  "Identsym", "hole_egg", "start_egg", "hole_Uses", "start_Uses",
  "hole_Strings", "start_Strings", "hole_Declarations",
  "start_Declarations", "hole_Declaration", "start_Declaration",
  "hole_Expression", "start_Expression", "hole_Params", "start_Params",
  "hole_Statements", "start_Statements", "hole_Statement",
  "start_Statement", "hole_MessageKind", "start_MessageKind",
  "hole_Message", "start_Message", "hole_SubMessages", "start_SubMessages",
  "hole_SubMessage", "start_SubMessage", "hole_Group", "start_Group",
  "hole_OPTMORE_Group", "start_OPTMORE_Group",
  "hole_ALT_Stringsym_SEP_commasym", "start_ALT_Stringsym_SEP_commasym",
  "hole_OPTMORE_Declaration", "start_OPTMORE_Declaration",
  "hole_MORE_Expression", "start_MORE_Expression",
  "hole_ALT_Expression_SEP_commasym", "start_ALT_Expression_SEP_commasym",
  "hole_OPTMORE_Statement", "start_OPTMORE_Statement", "hole_OPT_fatalsym",
  "start_OPT_fatalsym", "hole_ALT_SubMessage_SEP_commasym",
  "start_ALT_SubMessage_SEP_commasym",
  "hole_OPT_openparsym_Identsym_closeparsym",
  "start_OPT_openparsym_Identsym_closeparsym", "hole_OPT_groupsym",
  "start_OPT_groupsym", "$accept", "egg", "Uses", "Strings",
  "Declarations", "Declaration", "Expression", "Params", "Statements",
  "Statement", "MessageKind", "Message", "SubMessages", "SubMessage",
  "Group", "OPTMORE_Group", "ALT_Stringsym_SEP_commasym",
  "OPTMORE_Declaration", "MORE_Expression", "ALT_Expression_SEP_commasym",
  "OPTMORE_Statement", "OPT_fatalsym", "ALT_SubMessage_SEP_commasym",
  "OPT_openparsym_Identsym_closeparsym", "OPT_groupsym", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned char yyr1[] =
{
       0,    70,    71,    72,    73,    74,    75,    76,    76,    76,
      77,    78,    79,    79,    80,    80,    80,    80,    80,    81,
      82,    83,    84,    85,    85,    86,    86,    87,    87,    88,
      88,    89,    89,    90,    90,    91,    91,    92,    92,    93,
      93,    94,    94,    71,    71,    72,    71,    73,    71,    74,
      71,    75,    71,    76,    71,    77,    71,    78,    71,    79,
      71,    80,    71,    81,    71,    82,    71,    83,    71,    84,
      71,    85,    71,    86,    71,    87,    71,    88,    71,    89,
      71,    90,    71,    91,    71,    92,    71,    93,    71,    94,
      71
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     2,     3,     1,     1,     4,     1,     4,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     4,
       1,     2,     8,     0,     2,     1,     3,     0,     2,     1,
       2,     1,     3,     0,     2,     0,     1,     1,     3,     0,
       3,     0,     1,     1,     2,     1,     2,     1,     2,     1,
       2,     1,     2,     1,     2,     1,     2,     1,     2,     1,
       2,     1,     2,     1,     2,     1,     2,     1,     2,     1,
       2,     1,     2,     1,     2,     1,     2,     1,     2,     1,
       2,     1,     2,     1,     2,     1,     2,     1,     2,     1,
       2
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned char yydefact[] =
{
       0,     0,    43,     0,    45,     0,     0,    27,     0,     0,
       0,    33,    35,     0,    35,     0,     0,    35,    23,     0,
      27,     0,     0,    33,    35,     0,    39,    41,     0,    23,
      25,    47,    73,     0,     4,    44,    46,    48,    14,    15,
      16,    17,    18,    49,    51,    61,    75,    50,    27,     0,
       5,    52,     7,     9,    53,    54,    55,    79,    31,    56,
      10,    36,    57,    59,    63,    69,    81,    83,    58,    33,
      12,    13,    11,     0,    60,    62,    64,     0,    65,    67,
      85,     0,    66,    37,    20,    68,    70,     0,    71,    23,
      72,    74,    76,    77,    29,    78,    80,    82,    84,    86,
       0,    87,    88,    42,    89,    90,     1,     2,     0,     3,
      28,     0,     0,     0,    34,    39,     0,    21,     0,    39,
      24,    30,     0,    26,     0,     0,    32,     0,    41,    38,
      40,     6,     8,    19,     0,    27,    33,     0,    22
};

/* YYDEFGOTO[NTERM-NUM]. */
static const short yydefgoto[] =
{
      -1,    28,    29,    33,    47,    48,    58,    59,    68,    69,
      81,    70,   127,    83,    71,    90,    34,    50,    95,    60,
      72,    73,    84,   128,   105
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -25
static const short yypact[] =
{
      86,     2,   -25,    86,   -25,    36,     2,   154,   202,   138,
     171,    76,    13,   228,    14,    22,   178,     9,   123,     7,
     166,   148,   177,   119,     3,    27,    -2,    33,    23,   123,
      21,   -25,   -25,    43,   -25,   -25,   -25,   -25,   -25,   -25,
     -25,   -25,   -25,   -25,   -25,   -25,   -25,   -25,   166,    35,
     -25,   -25,   -25,    37,   -25,   -25,   -25,   -25,    58,   -25,
     -25,   -25,   -25,   -25,   -25,   -25,   -25,   -25,   -25,   119,
     -25,   -25,   -25,    51,   -25,   -25,   -25,    56,   -25,   -25,
     -25,    61,   -25,    77,   -25,   -25,   -25,    63,   -25,   123,
     -25,   -25,   -25,   -25,   148,   -25,   -25,   -25,   -25,   -25,
      64,   -25,   -25,   -25,   -25,   -25,   -25,   -25,     7,   -25,
     -25,   148,   171,   177,   -25,    34,    22,   -25,    27,    -2,
     -25,   -25,    78,   -25,    88,    85,   -25,    96,    33,   -25,
     -25,   -25,   -25,   -25,    87,   154,    76,    89,   -25
};

/* YYPGOTO[NTERM-NUM].  */
static const short yypgoto[] =
{
     -25,   101,   111,   100,   -13,   112,    -6,    20,     6,   122,
      -7,   132,   133,   134,   -10,   -20,   -15,     5,   -24,   -17,
     -11,     0,   -23,   126,    26
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -36
static const short yytable[] =
{
      49,    49,    99,    55,    91,    96,    75,    86,    89,   107,
      61,   100,    97,    49,    77,    94,    61,    87,    87,    89,
      61,    61,    30,   106,    98,    92,   108,    30,    31,    87,
      38,    39,    40,    41,    42,    38,    39,    40,    41,    42,
       1,    49,    38,    39,    40,    41,    42,   100,   103,   109,
     112,    63,   111,   110,    32,    64,    64,    65,   114,    32,
       4,    65,    45,   113,   101,    67,    78,    45,    79,   120,
     121,    67,   115,    79,    45,    67,    67,   116,    78,    89,
      79,   117,   118,    61,   119,   122,    80,   124,    94,    87,
       1,    80,   130,   123,   131,   129,   126,   -35,    80,   132,
     101,   104,   133,   135,    35,    94,    37,   138,     2,     3,
       4,     5,    62,     6,    63,     7,    36,     8,    64,     9,
      51,    10,   136,    11,    65,    12,    61,    13,    49,    14,
      61,    15,   125,    16,    74,    17,    66,    18,    67,    19,
     -35,    20,   137,    21,   -35,    22,    76,    23,    82,    24,
      85,    25,   102,    26,   134,    27,     0,    63,    52,    53,
       0,    64,    38,    39,    40,    41,    42,    65,    52,    53,
      54,    65,     0,    88,    38,    39,    40,    41,    42,    66,
      54,    67,    43,     0,    44,    67,    38,    39,    40,    41,
      42,    52,    53,     0,    45,     0,    44,    52,    53,     0,
       0,     0,     0,    54,    93,    56,    45,     0,    46,    54,
      38,    39,    40,    41,    42,     0,     0,     0,    45,     0,
      46,     0,     0,     0,    79,     0,     0,     0,     0,    57,
       0,     0,    44,     0,     0,    57,    38,    39,    40,    41,
      42,     0,    45,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    45
};

static const short yycheck[] =
{
       7,     8,    25,     9,    19,    22,    13,    17,    18,    29,
       7,    13,    23,    20,    14,    21,     7,    17,    18,    29,
       7,     7,    20,     0,    24,    20,     5,    20,    26,    29,
       8,     9,    10,    11,    12,     8,     9,    10,    11,    12,
       4,    48,     8,     9,    10,    11,    12,    13,    15,     6,
      13,    38,    17,    48,    52,    42,    42,    48,    69,    52,
      24,    48,    40,     5,    66,    62,    44,    40,    46,    89,
      94,    62,    21,    46,    40,    62,    62,    21,    44,    89,
      46,    20,     5,     7,    21,    21,    64,   111,    94,    89,
       4,    64,    14,   108,     6,   118,   113,    21,    64,    14,
      66,    68,     6,    16,     3,   111,     6,    18,    22,    23,
      24,    25,    36,    27,    38,    29,     5,    31,    42,    33,
       8,    35,   135,    37,    48,    39,     7,    41,   135,    43,
       7,    45,   112,    47,    12,    49,    60,    51,    62,    53,
      21,    55,   136,    57,    21,    59,    14,    61,    15,    63,
      16,    65,    26,    67,   128,    69,    -1,    38,    20,    21,
      -1,    42,     8,     9,    10,    11,    12,    48,    20,    21,
      32,    48,    -1,    50,     8,     9,    10,    11,    12,    60,
      32,    62,    28,    -1,    30,    62,     8,     9,    10,    11,
      12,    20,    21,    -1,    40,    -1,    30,    20,    21,    -1,
      -1,    -1,    -1,    32,    56,    34,    40,    -1,    54,    32,
       8,     9,    10,    11,    12,    -1,    -1,    -1,    40,    -1,
      54,    -1,    -1,    -1,    46,    -1,    -1,    -1,    -1,    58,
      -1,    -1,    30,    -1,    -1,    58,     8,     9,    10,    11,
      12,    -1,    40,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    40
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned char yystos[] =
{
       0,     4,    22,    23,    24,    25,    27,    29,    31,    33,
      35,    37,    39,    41,    43,    45,    47,    49,    51,    53,
      55,    57,    59,    61,    63,    65,    67,    69,    71,    72,
      20,    26,    52,    73,    86,    71,    72,    73,     8,     9,
      10,    11,    12,    28,    30,    40,    54,    74,    75,    80,
      87,    75,    20,    21,    32,    76,    34,    58,    76,    77,
      89,     7,    36,    38,    42,    48,    60,    62,    78,    79,
      81,    84,    90,    91,    79,    80,    81,    91,    44,    46,
      64,    80,    82,    83,    92,    83,    84,    91,    50,    84,
      85,    86,    87,    56,    76,    88,    89,    90,    91,    92,
      13,    66,    93,    15,    68,    94,     0,    85,     5,     6,
      87,    17,    13,     5,    90,    21,    21,    20,     5,    21,
      85,    88,    21,    86,    88,    77,    89,    82,    93,    92,
      14,     6,    14,     6,    94,    16,    74,    78,    18
};

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("syntax error: cannot back up");\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)		\
   ((Current).first_line   = (Rhs)[1].first_line,	\
    (Current).first_column = (Rhs)[1].first_column,	\
    (Current).last_line    = (Rhs)[N].last_line,	\
    (Current).last_column  = (Rhs)[N].last_column)
#endif

/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

# define YYDSYMPRINT(Args)			\
do {						\
  if (yydebug)					\
    yysymprint Args;				\
} while (0)

# define YYDSYMPRINTF(Title, Token, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr, 					\
                  Token, Value, Location);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_stack_print (short *bottom, short *top)
#else
static void
yy_stack_print (bottom, top)
    short *bottom;
    short *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (/* Nothing. */; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_reduce_print (int yyrule)
#else
static void
yy_reduce_print (yyrule)
    int yyrule;
#endif
{
  int yyi;
  unsigned int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %u), ",
             yyrule - 1, yylno);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytname [yyrhs[yyi]]);
  YYFPRINTF (stderr, "-> %s\n", yytname [yyr1[yyrule]]);
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (Rule);		\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YYDSYMPRINT(Args)
# define YYDSYMPRINTF(Title, Token, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if defined (YYMAXDEPTH) && YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

#endif /* !YYERROR_VERBOSE */



#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
#else
static void
yysymprint (yyoutput, yytype, yyvaluep, yylocationp)
    FILE *yyoutput;
    int yytype;
    YYSTYPE *yyvaluep;
    YYLTYPE *yylocationp;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;
  (void) yylocationp;

  if (yytype < YYNTOKENS)
    {
      YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
# ifdef YYPRINT
      YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
    }
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}

#endif /* ! YYDEBUG */
/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yydestruct (int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
#else
static void
yydestruct (yytype, yyvaluep, yylocationp)
    int yytype;
    YYSTYPE *yyvaluep;
    YYLTYPE *yylocationp;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;
  (void) yylocationp;

  switch (yytype)
    {

      default:
        break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM);
# else
int yyparse ();
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;
/* Location data for the lookahead symbol.  */
YYLTYPE yylloc;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM)
# else
int yyparse (YYPARSE_PARAM)
  void *YYPARSE_PARAM;
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short	yyssa[YYINITDEPTH];
  short *yyss = yyssa;
  register short *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;

  /* The location stack.  */
  YYLTYPE yylsa[YYINITDEPTH];
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;
  YYLTYPE *yylerrsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;
  yylsp = yyls;
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short *yyss1 = yyss;
	YYLTYPE *yyls1 = yyls;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yyls1, yysize * sizeof (*yylsp),
		    &yystacksize);
	yyls = yyls1;
	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	short *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);
	YYSTACK_RELOCATE (yyls);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YYDSYMPRINTF ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %s, ", yytname[yytoken]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
  *++yylsp = yylloc;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location. */
  YYLLOC_DEFAULT (yyloc, yylsp - yylen, yylen);
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:

    { yyval.egg_type = Create_egg_egg(make_post_src_info(yylsp[-1].first_line, yylsp[0].last_line), yyvsp[-1].Uses_type, yyvsp[0].OPTMORE_Group_type);
    Decorate_egg(yyval.egg_type);
  ;}
    break;

  case 3:

    { yyval.Uses_type = Create_egg_Uses(make_post_src_info(yylsp[-2].first_line, yylsp[0].last_line), yyvsp[-1].Strings_type);
  ;}
    break;

  case 4:

    {
    yyval.Strings_type = yyvsp[0].ALT_Stringsym_SEP_commasym_type;
  ;}
    break;

  case 5:

    {
    yyval.Declarations_type = yyvsp[0].OPTMORE_Declaration_type;
  ;}
    break;

  case 6:

    { yyval.Declaration_type = Create_egg_Declaration(make_post_src_info(yylsp[-3].first_line, yylsp[0].last_line), yyvsp[-3].MessageKind_type, yyvsp[-1].MORE_Expression_type);
  ;}
    break;

  case 7:

    { yyval.Expression_type = Create_egg_StringExpr(make_post_src_info(yylsp[0].first_line, yylsp[0].last_line), yyvsp[0].Stringsym_type);
  ;}
    break;

  case 8:

    { yyval.Expression_type = Create_egg_CallExpr(make_post_src_info(yylsp[-3].first_line, yylsp[0].last_line), yyvsp[-3].Identsym_type, yyvsp[-1].Params_type);
  ;}
    break;

  case 9:

    { yyval.Expression_type = Create_egg_IdExpr(make_post_src_info(yylsp[0].first_line, yylsp[0].last_line), yyvsp[0].Identsym_type);
  ;}
    break;

  case 10:

    {
    yyval.Params_type = yyvsp[0].ALT_Expression_SEP_commasym_type;
  ;}
    break;

  case 11:

    {
    yyval.Statements_type = yyvsp[0].OPTMORE_Statement_type;
  ;}
    break;

  case 12:

    {
    yyval.Statement_type = yyvsp[0].Message_type;
  ;}
    break;

  case 13:

    {
    yyval.Statement_type = yyvsp[0].Group_type;
  ;}
    break;

  case 14:

    { yyval.MessageKind_type = egg_ErrorMsg; ;}
    break;

  case 15:

    { yyval.MessageKind_type = egg_WarningMsg; ;}
    break;

  case 16:

    { yyval.MessageKind_type = egg_DisabledMsg; ;}
    break;

  case 17:

    { yyval.MessageKind_type = egg_KeyMsg; ;}
    break;

  case 18:

    { yyval.MessageKind_type = egg_PostMsg; ;}
    break;

  case 19:

    { yyval.Message_type = Create_egg_Message(make_post_src_info(yylsp[-3].first_line, yylsp[0].last_line), yyvsp[-3].OPT_fatalsym_type, yyvsp[-2].Identsym_type, yyvsp[-1].SubMessages_type);
  ;}
    break;

  case 20:

    {
    yyval.SubMessages_type = yyvsp[0].ALT_SubMessage_SEP_commasym_type;
  ;}
    break;

  case 21:

    { yyval.SubMessage_type = Create_egg_SubMessage(make_post_src_info(yylsp[-1].first_line, yylsp[0].last_line), yyvsp[-1].MessageKind_type, yyvsp[0].Stringsym_type);
  ;}
    break;

  case 22:

    { yyval.Group_type = Create_egg_Group(make_post_src_info(yylsp[-7].first_line, yylsp[0].last_line), yyvsp[-7].OPT_fatalsym_type, yyvsp[-6].Identsym_type, yyvsp[-5].OPT_openparsym_Identsym_closeparsym_type, yyvsp[-4].OPT_groupsym_type, yyvsp[-2].Declarations_type, yyvsp[-1].Statements_type);
  ;}
    break;

  case 23:

    {
    yyval.OPTMORE_Group_type = NULL;
  ;}
    break;

  case 24:

    {
    yyval.OPTMORE_Group_type = Create_List_egg_Statement(yyvsp[-1].Group_type, yyvsp[0].OPTMORE_Group_type);
  ;}
    break;

  case 25:

    {
    yyval.ALT_Stringsym_SEP_commasym_type = Create_List_String(yyvsp[0].Stringsym_type, NULL);
  ;}
    break;

  case 26:

    {
    yyval.ALT_Stringsym_SEP_commasym_type = Create_List_String(yyvsp[-2].Stringsym_type, yyvsp[0].ALT_Stringsym_SEP_commasym_type);
  ;}
    break;

  case 27:

    {
    yyval.OPTMORE_Declaration_type = NULL;
  ;}
    break;

  case 28:

    {
    yyval.OPTMORE_Declaration_type = Create_List_egg_Declaration(yyvsp[-1].Declaration_type, yyvsp[0].OPTMORE_Declaration_type);
  ;}
    break;

  case 29:

    {
    yyval.MORE_Expression_type = Create_List_egg_Expression(yyvsp[0].Expression_type, NULL);
  ;}
    break;

  case 30:

    {
    yyval.MORE_Expression_type = Create_List_egg_Expression(yyvsp[-1].Expression_type, yyvsp[0].MORE_Expression_type);
  ;}
    break;

  case 31:

    {
    yyval.ALT_Expression_SEP_commasym_type = Create_List_egg_Expression(yyvsp[0].Expression_type, NULL);
  ;}
    break;

  case 32:

    {
    yyval.ALT_Expression_SEP_commasym_type = Create_List_egg_Expression(yyvsp[-2].Expression_type, yyvsp[0].ALT_Expression_SEP_commasym_type);
  ;}
    break;

  case 33:

    {
    yyval.OPTMORE_Statement_type = NULL;
  ;}
    break;

  case 34:

    {
    yyval.OPTMORE_Statement_type = Create_List_egg_Statement(yyvsp[-1].Statement_type, yyvsp[0].OPTMORE_Statement_type);
  ;}
    break;

  case 35:

    {
    yyval.OPT_fatalsym_type = FALSE;
  ;}
    break;

  case 36:

    {
    yyval.OPT_fatalsym_type = TRUE;
  ;}
    break;

  case 37:

    {
    yyval.ALT_SubMessage_SEP_commasym_type = Create_List_egg_SubMessage(yyvsp[0].SubMessage_type, NULL);
  ;}
    break;

  case 38:

    {
    yyval.ALT_SubMessage_SEP_commasym_type = Create_List_egg_SubMessage(yyvsp[-2].SubMessage_type, yyvsp[0].ALT_SubMessage_SEP_commasym_type);
  ;}
    break;

  case 39:

    {
    yyval.OPT_openparsym_Identsym_closeparsym_type = NULL;
  ;}
    break;

  case 40:

    {
    yyval.OPT_openparsym_Identsym_closeparsym_type = yyvsp[-1].Identsym_type;
  ;}
    break;

  case 41:

    {
    yyval.OPT_groupsym_type = FALSE;
  ;}
    break;

  case 42:

    {
    yyval.OPT_groupsym_type = TRUE;
  ;}
    break;

  case 43:

    { yyval.egg_type = (egg_egg)Get_sub_tree (); ;}
    break;

  case 44:

    { egg_multi_action ((void*)yyvsp[0].egg_type); YYACCEPT; ;}
    break;

  case 45:

    { yyval.Uses_type = (egg_Uses)Get_sub_tree (); ;}
    break;

  case 46:

    { egg_multi_action ((void*)yyvsp[0].Uses_type); YYACCEPT; ;}
    break;

  case 47:

    { yyval.Strings_type = (List_String)Get_sub_tree (); ;}
    break;

  case 48:

    { egg_multi_action ((void*)yyvsp[0].Strings_type); YYACCEPT; ;}
    break;

  case 49:

    { yyval.Declarations_type = (List_egg_Declaration)Get_sub_tree (); ;}
    break;

  case 50:

    { egg_multi_action ((void*)yyvsp[0].Declarations_type); YYACCEPT; ;}
    break;

  case 51:

    { yyval.Declaration_type = (egg_Declaration)Get_sub_tree (); ;}
    break;

  case 52:

    { egg_multi_action ((void*)yyvsp[0].Declaration_type); YYACCEPT; ;}
    break;

  case 53:

    { yyval.Expression_type = (egg_Expression)Get_sub_tree (); ;}
    break;

  case 54:

    { egg_multi_action ((void*)yyvsp[0].Expression_type); YYACCEPT; ;}
    break;

  case 55:

    { yyval.Params_type = (List_egg_Expression)Get_sub_tree (); ;}
    break;

  case 56:

    { egg_multi_action ((void*)yyvsp[0].Params_type); YYACCEPT; ;}
    break;

  case 57:

    { yyval.Statements_type = (List_egg_Statement)Get_sub_tree (); ;}
    break;

  case 58:

    { egg_multi_action ((void*)yyvsp[0].Statements_type); YYACCEPT; ;}
    break;

  case 59:

    { yyval.Statement_type = (egg_Statement)Get_sub_tree (); ;}
    break;

  case 60:

    { egg_multi_action ((void*)yyvsp[0].Statement_type); YYACCEPT; ;}
    break;

  case 61:

    { yyval.MessageKind_type = (egg_MessageKind)Get_sub_tree (); ;}
    break;

  case 62:

    { egg_multi_action ((void*)yyvsp[0].MessageKind_type); YYACCEPT; ;}
    break;

  case 63:

    { yyval.Message_type = (egg_Statement)Get_sub_tree (); ;}
    break;

  case 64:

    { egg_multi_action ((void*)yyvsp[0].Message_type); YYACCEPT; ;}
    break;

  case 65:

    { yyval.SubMessages_type = (List_egg_SubMessage)Get_sub_tree (); ;}
    break;

  case 66:

    { egg_multi_action ((void*)yyvsp[0].SubMessages_type); YYACCEPT; ;}
    break;

  case 67:

    { yyval.SubMessage_type = (egg_SubMessage)Get_sub_tree (); ;}
    break;

  case 68:

    { egg_multi_action ((void*)yyvsp[0].SubMessage_type); YYACCEPT; ;}
    break;

  case 69:

    { yyval.Group_type = (egg_Statement)Get_sub_tree (); ;}
    break;

  case 70:

    { egg_multi_action ((void*)yyvsp[0].Group_type); YYACCEPT; ;}
    break;

  case 71:

    { yyval.OPTMORE_Group_type = (List_egg_Statement)Get_sub_tree (); ;}
    break;

  case 72:

    { egg_multi_action ((void*)yyvsp[0].OPTMORE_Group_type); YYACCEPT; ;}
    break;

  case 73:

    { yyval.ALT_Stringsym_SEP_commasym_type = (List_String)Get_sub_tree (); ;}
    break;

  case 74:

    { egg_multi_action ((void*)yyvsp[0].ALT_Stringsym_SEP_commasym_type); YYACCEPT; ;}
    break;

  case 75:

    { yyval.OPTMORE_Declaration_type = (List_egg_Declaration)Get_sub_tree (); ;}
    break;

  case 76:

    { egg_multi_action ((void*)yyvsp[0].OPTMORE_Declaration_type); YYACCEPT; ;}
    break;

  case 77:

    { yyval.MORE_Expression_type = (List_egg_Expression)Get_sub_tree (); ;}
    break;

  case 78:

    { egg_multi_action ((void*)yyvsp[0].MORE_Expression_type); YYACCEPT; ;}
    break;

  case 79:

    { yyval.ALT_Expression_SEP_commasym_type = (List_egg_Expression)Get_sub_tree (); ;}
    break;

  case 80:

    { egg_multi_action ((void*)yyvsp[0].ALT_Expression_SEP_commasym_type); YYACCEPT; ;}
    break;

  case 81:

    { yyval.OPTMORE_Statement_type = (List_egg_Statement)Get_sub_tree (); ;}
    break;

  case 82:

    { egg_multi_action ((void*)yyvsp[0].OPTMORE_Statement_type); YYACCEPT; ;}
    break;

  case 83:

    { yyval.OPT_fatalsym_type = (Bool)Get_sub_tree (); ;}
    break;

  case 84:

    { egg_multi_action ((void*)yyvsp[0].OPT_fatalsym_type); YYACCEPT; ;}
    break;

  case 85:

    { yyval.ALT_SubMessage_SEP_commasym_type = (List_egg_SubMessage)Get_sub_tree (); ;}
    break;

  case 86:

    { egg_multi_action ((void*)yyvsp[0].ALT_SubMessage_SEP_commasym_type); YYACCEPT; ;}
    break;

  case 87:

    { yyval.OPT_openparsym_Identsym_closeparsym_type = (Ident)Get_sub_tree (); ;}
    break;

  case 88:

    { egg_multi_action ((void*)yyvsp[0].OPT_openparsym_Identsym_closeparsym_type); YYACCEPT; ;}
    break;

  case 89:

    { yyval.OPT_groupsym_type = (Bool)Get_sub_tree (); ;}
    break;

  case 90:

    { egg_multi_action ((void*)yyvsp[0].OPT_groupsym_type); YYACCEPT; ;}
    break;


    }

/* Line 993 of yacc.c.  */


  yyvsp -= yylen;
  yyssp -= yylen;
  yylsp -= yylen;

  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  int yytype = YYTRANSLATE (yychar);
	  const char* yyprefix;
	  char *yymsg;
	  int yyx;

	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  int yyxbegin = yyn < 0 ? -yyn : 0;

	  /* Stay within bounds of both yycheck and yytname.  */
	  int yychecklim = YYLAST - yyn;
	  int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
	  int yycount = 0;

	  yyprefix = ", expecting ";
	  for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      {
		yysize += yystrlen (yyprefix) + yystrlen (yytname [yyx]);
		yycount += 1;
		if (yycount == 5)
		  {
		    yysize = 0;
		    break;
		  }
	      }
	  yysize += (sizeof ("syntax error, unexpected ")
		     + yystrlen (yytname[yytype]));
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "syntax error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[yytype]);

	      if (yycount < 5)
		{
		  yyprefix = ", expecting ";
		  for (yyx = yyxbegin; yyx < yyxend; ++yyx)
		    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
		      {
			yyp = yystpcpy (yyp, yyprefix);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yyprefix = " or ";
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("syntax error; also virtual memory exhausted");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror ("syntax error");
    }

  yylerrsp = yylsp;

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* If at end of input, pop the error token,
	     then the rest of the stack, then return failure.  */
	  if (yychar == YYEOF)
	     for (;;)
	       {
		 YYPOPSTACK;
		 if (yyssp == yyss)
		   YYABORT;
		 YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
		 yydestruct (yystos[*yyssp], yyvsp, yylsp);
	       }
        }
      else
	{
	  YYDSYMPRINTF ("Error: discarding", yytoken, &yylval, &yylloc);
	  yydestruct (yytoken, &yylval, &yylloc);
	  yychar = YYEMPTY;
	  *++yylerrsp = yylloc;
	}
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

#ifdef __GNUC__
  /* Pacify GCC when the user code never invokes YYERROR and the label
     yyerrorlab therefore never appears in user code.  */
  if (0)
     goto yyerrorlab;
#endif

  yyvsp -= yylen;
  yyssp -= yylen;
  yystate = *yyssp;
  yylerrsp = yylsp;
  *++yylerrsp = yyloc;
  yylsp -= yylen;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
      yydestruct (yystos[yystate], yyvsp, yylsp);
      YYPOPSTACK;
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;
  YYLLOC_DEFAULT (yyloc, yylsp, yylerrsp - yylsp);
  *++yylsp = yyloc;

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*----------------------------------------------.
| yyoverflowlab -- parser overflow comes here.  |
`----------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}



